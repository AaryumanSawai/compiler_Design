1) started test 2-:
2) completed decleration and generation of symbol table
3) added relational operators