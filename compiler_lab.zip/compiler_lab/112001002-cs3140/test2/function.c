#include <stdlib.h>
#include <stdio.h>
int i = 0;
struct symbol sym_table[20];

struct node *create_tree(struct node *right, struct node *left, int root, int val2)
{
	struct node *root1 = (struct node *)malloc(sizeof(struct node));
	root1->left = left;
	root1->right = right;
	root1->type = root;
	root1->val = val2;
	return root1;
}
struct node *create_node(int x, int val1, int sym_table_ind8)
{
	struct node *n1 = (struct node *)malloc(sizeof(struct node));
	n1->type = x;
	n1->right = NULL;
	n1->left = NULL;
	n1->val = val1;
	n1->sym_table_ind9 = sym_table_ind8;
	return n1;
}

void print_tree(struct node *root)
{
	if (root == NULL)
	{
		return;
	}
	print_tree(root->left);
	printf(" %d ", root->type);
	print_tree(root->right);
}

void eval(struct node *root)
{
	if (root == NULL)
	{
		return;
	}

	if (root->type == 1)
	{
		printf("PLUS ");
	}

	if (root->type == 2)
	{
		printf("SUB ");
	}

	if (root->type == 3)
	{
		printf("MUL ");
	}

	if (root->type == 4)
	{
		printf("DIV ");
	}
	if (root->type == 5)
	{
		printf("MOD ");
	}
	if (root->type == 6)
	{
		printf("LESS ");
	}
	if (root->type == 7)
	{
		printf("GREATER ");
	}
	if (root->type == 8)
	{
		printf("GEQ ");
	}

	if (root->type == 9)
	{
		printf("LEQ ");
	}
	if (root->type == 10)
	{
		printf("NEQ ");
	}
	if (root->type == 11)
	{
		printf("EQUAL EQUAL ");
	}
	if (root->type == 12)
	{
		printf("NOT OF ");
	}
	if (root->type == 13)
	{
		printf("LOGICAL AND ");
	}
	if (root->type == 14)
	{
		printf("LOGICAL OR ");
	}
	if (root->type == 15)
	{
		printf("NUM ");
	}
	if (root->type == 16)
	{
		printf("VAR ");
	}
	if (root->type == 17)
	{
		printf("ARRREF VAR ");
		eval(root->arr_ind_expr7);
	}
	if (root->type == 18)
	{
		printf("TRUE ");
	}
	if (root->type == 19)
	{
		printf("FALSE ");
	}

	eval(root->left);
	eval(root->right);
}

int next_free_symbol_table_entry()
{
	return i;
}

void insert(char *var_name2, int x, int j, bool is_array2, int array_size2)
{
	int *arr = NULL;
	if (is_array2 == 1)
	{
		arr = (int *)malloc((array_size2) * sizeof(int));
		for (int i2 = 0; i2 < array_size2; i2++)
		{
			arr[i2] = 0;
		}
	}

	sym_table[j] = (struct symbol){
		.str = var_name2,
		.t = x,
		.val = 0,
		.a = arr,

	};
}

struct var_node *create_link_list(char *var_name, struct var_node *next, bool is_array1, int size1)
{
	struct var_node *ll = (struct var_node *)malloc(sizeof(struct var_node));
	ll->var_Name = var_name;
	ll->sym_index = i;
	ll->is_array = is_array1;
	ll->array_size = size1;
	ll->next = next;
	// printf("%s %d\n" ,var_name,i);
	i = i + 1;
	return ll;
}

void print_decl(struct var_node *ll1)
{
	// struct var_node * ll2 = (struct var_node *) malloc (sizeof(struct var_node));
	// ll2 = ll1;
	while (ll1 != NULL)
	{
		if (ll1->is_array)
		{
			printf("ARR VAR %d, ", ll1->array_size);
		}
		else
		{
			printf("VAR, ");
		}
		// printf("symbol_index: %d ",ll1->sym_index);
		ll1 = ll1->next;
	}
	printf("\n");
}


void print_symbol_table()
{
	printf("symbol table\n");
	for (int i1 = 0; i1 < 20; i1++)
	{
		if (sym_table[i1].a == NULL)
			printf("%s=%d \n", sym_table[i1].str, sym_table[i1].val);
		else
		{
			printf("%s={", sym_table[i1].str);
			for(int i = 0; i<5;i++)
			{
				printf("%d, ",*((sym_table[i1].a)+i));
			}
			printf("}");
		}
	}
}
// create dec_node tree
struct dec_node *create_decl_tree(int datatype, struct var_node *ll2)
{
	struct dec_node *dec1 = (struct dec_node *)malloc(sizeof(struct dec_node));
	dec1->left = datatype;
	dec1->right = ll2;
	return dec1;
}

int is_present_in_symbol_table(char *x)
{
	int i2 = 0;
	while (sym_table[i2].str != NULL && i2 < 20)
	{
		if (strcmp(sym_table[i2].str, x) == 0)
		{
			return i2;
		}
		i2++;
	}
	return -1;
}
// create list of decl nodes
struct list_dec_node *create_decl_link_list(struct dec_node *gdecl1, struct list_dec_node *decl_list)
{
	struct list_dec_node *head = (struct list_dec_node *)malloc(sizeof(struct list_dec_node));
	head->gdecl = gdecl1;
	head->next = decl_list;
	return head;
}
void print_gdecl(struct dec_node *decl4)
{
	printf("DECL ");
	if (decl4->left == 0)
	{
		printf("INT ");
	}
	else
	{
		printf("BOOL ");
	}
	print_decl(decl4->right);
}
void print_all_declerations(struct list_dec_node *head1)
{
	struct list_dec_node *head2 = head1;
	while (head2 != NULL)
	{
		struct dec_node *decl3 = head2->gdecl;
		print_gdecl(decl3);

		head2 = head2->next;
	}
}

struct var_node *linker(struct var_node *first, struct var_node *second)
{
	first->next = second;
	return first;
}

struct var_expr_node *create_var_expr_node(int sym_ind, int arr_ind, struct ass_stmt *semi_assign1)
{
	struct var_expr_node *new_var_expr_node = (struct var_expr_node *)malloc(sizeof(struct var_expr_node));
	new_var_expr_node->sym_table_index = sym_ind;
	new_var_expr_node->array_index = arr_ind;

	new_var_expr_node->semi_assign = semi_assign1;
	return new_var_expr_node;
}

struct ass_stmt *create_semi_assign(int var_type1, struct node *expr1, struct node *arr_ind_expr1, bool in_while1, char *var_name4, int sym_tab_ind4)
{
	struct ass_stmt *new_semi_assign = (struct ass_stmt *)malloc(sizeof(struct ass_stmt));
	new_semi_assign->var_type = var_type1;
	new_semi_assign->expr = expr1;
	new_semi_assign->arr_ind_expr = arr_ind_expr1;
	new_semi_assign->in_while = in_while1;
	new_semi_assign->var_name3 = var_name4;
	new_semi_assign->sym_table_ind = sym_tab_ind4;
	return new_semi_assign;
}

struct statement_node *create_statement_node(int stmt_type, struct ass_stmt *assignment2, struct cond_st *cond_st5, struct write_node *write_node4, struct statement_node *next1)
{
	struct statement_node *new_stmt_node = (struct statement_node *)malloc(sizeof(struct statement_node));
	new_stmt_node->statement_type = stmt_type;
	new_stmt_node->assignment = assignment2;
	new_stmt_node->cond_st4 = cond_st5;
	new_stmt_node->write_node3 = write_node4;
	new_stmt_node->next = next1;

	return new_stmt_node;
}
void print_assignment(struct ass_stmt *assign3)
{
	if (assign3 != NULL)
	{
		printf("ASSIGN ");
		if (assign3->var_type == 0)
		{
			printf("VAR ");
			eval(assign3->expr);
			printf("\n");
		}
		else
		{
			printf("ARRREF VAR ");
			eval(assign3->arr_ind_expr);
			// printf("%d %p %p %d",(assign3->arr_ind_expr)->type,(assign3->arr_ind_expr)->left,(assign3->arr_ind_expr)->right,(assign3->arr_ind_expr)->val);
			eval(assign3->expr);
			printf("\n");
		}
	}
	else{
		return;
	}
}
void print_condition(struct cond_st *cond_st6)
{
	if (cond_st6->st_type == 0)
	{
		printf("WHILE EXPR ");
		eval(cond_st6->expr_2);
		printf("\n");
		print_statement(cond_st6->stmt_list2);
	}
	else if (cond_st6->st_type == 1)
	{
		printf("IF ");
		eval(cond_st6->expr_2);
		printf("\n");
		print_statement(cond_st6->stmt_list2);
		printf("ELSE ");
		print_statement(cond_st6->extra_stmt_list2);
	}
}
void print_write(struct write_node *write_node6)
{
	printf("FUNCALL ");
	if (write_node6->write_expr != NULL)
	{
		eval(write_node6->write_expr);
		printf("\n");
	}
}
void print_statement(struct statement_node *statement)
{

	while (statement != NULL)
	{
		if (statement->statement_type == 0)
		{
			print_assignment(statement->assignment);
		}
		else if (statement->statement_type == 1)
		{
			print_condition(statement->cond_st4);
		}
		else if (statement->statement_type == 2)
		{
			print_write(statement->write_node3);
		}
		statement = statement->next;
	}
}
void update_expr(struct node *expr)
{
	if (expr == NULL)
	{
		return;
	}
	update_expr(expr->left);
	update_expr(expr->right);
	if (expr->type == 1)
	{
		expr->val = (expr->left->val) + (expr->right->val);
		
	}

	if (expr->type == 2)
	{
		expr->val = (expr->left->val) - (expr->right->val);
	}

	if (expr->type == 3)
	{
		expr->val = (expr->left->val) * (expr->right->val);
	}

	if (expr->type == 4)
	{
		expr->val = (expr->left->val) / (expr->right->val);
	}
	if (expr->type == 5)
	{
		expr->val = (expr->left->val) % (expr->right->val);
	}
	if (expr->type == 6)
	{
		expr->val = (expr->left->val) < (expr->right->val);
	}
	if (expr->type == 7)
	{
		expr->val = (expr->left->val) > (expr->right->val);
	}
	if (expr->type == 8)
	{
		expr->val = (expr->left->val) >= (expr->right->val);
	}

	if (expr->type == 9)
	{
		expr->val = (expr->left->val) <= (expr->right->val);
	}
	if (expr->type == 10)
	{
		expr->val = (expr->left->val) != (expr->right->val);
	}
	if (expr->type == 11)
	{
		expr->val = (expr->left->val) == (expr->right->val);
	}
	if (expr->type == 12)
	{
		(expr->val) = !( expr->right->val);
	}
	if (expr->type == 13)
	{
		expr->val = (expr->left->val) && (expr->right->val);
	}
	if (expr->type == 14)
	{
		expr->val = (expr->left->val) || (expr->right->val);

	}
	if (expr->type == 15)
	{
		return;
	}
	if (expr->type == 16)
	{
		// printf(" in update expr %d",sym_table[expr->sym_table_ind9].val);
		expr->val = sym_table[expr->sym_table_ind9].val;
	}
	if (expr->type == 17)
	{
		update_expr(expr->arr_ind_expr7);
		expr-> val = (sym_table[expr->sym_table_ind9].a)[expr->arr_ind_expr7->val];
	}
	if (expr->type == 18)
	{
		return;
	}
	if (expr->type == 19)
	{
		return;
	}
	
}
void run_assignment(struct ass_stmt *ass_st5)
{
	if (ass_st5->var_type == 0)
	{
		update_expr(ass_st5->expr);
		((sym_table[ass_st5->sym_table_ind]).val) = (ass_st5->expr->val);
		//printf("%d",sym_table[ass_st5->sym_table_ind].val);
		//update_expr(ass_st5->expr);
		
	}
	//a[2] = 3
	else
	{
		update_expr(ass_st5->expr);
		update_expr(ass_st5->arr_ind_expr);
		*((sym_table[ass_st5->sym_table_ind].a)+(ass_st5->arr_ind_expr->val))=ass_st5->expr->val;
		//update_expr(ass_st5->expr);
	}
}

void run_condition(struct cond_st *cond_st5)
{
	if(cond_st5->st_type == 0)
	{
		while((cond_st5->expr_2->val))
		{
			run_statement(cond_st5->stmt_list2);
			update_expr(cond_st5->expr_2);
			//printf("%d",cond_st5->expr_2->val);
		}
	}
	else if(cond_st5->st_type == 1)
	{
		if((cond_st5->expr_2->val))
		{
			run_statement(cond_st5->stmt_list2);
			update_expr(cond_st5->expr_2);
		}
		else
		{
			run_statement(cond_st5->extra_stmt_list2);
		}
	}

}

void run_write (struct write_node *write_node8)
{
	if(write_node8->write_expr != NULL)
	{
		update_expr(write_node8->write_expr);
		printf("%d",write_node8->write_expr->val);

	}
	else{
		printf("%s",write_node8->write_str);
	}
}

void run_statement(struct statement_node *statement)
{
	while (statement != NULL)
	{
		if (statement->statement_type == 0)
		{
			//printf("assignment running");
			run_assignment(statement->assignment);
		}
		else if (statement->statement_type == 1)
		{
			run_condition(statement->cond_st4);
		}
		else if (statement->statement_type == 2)
		{
			run_write(statement->write_node3);
		}
		statement = statement->next;
	}
}

struct cond_st *create_condition_node(int st_type1, struct node *expr2, struct statement_node *stmt_list3, struct statement_node *stmt_list4)
{
	struct cond_st *new_cond_node = (struct cond_st *)malloc(sizeof(struct cond_st));
	new_cond_node->st_type = st_type1;
	new_cond_node->expr_2 = expr2;
	new_cond_node->stmt_list2 = stmt_list3;
	new_cond_node->extra_stmt_list2 = stmt_list4;
	return new_cond_node;
}

struct write_node *create_write_node(struct node *write_expr1, char *write_str1)
{
	struct write_node *new_write_node = (struct write_node *)malloc(sizeof(struct write_node));
	new_write_node->write_expr = write_expr1;
	new_write_node->write_str = write_str1;
	return new_write_node;
}

