24 march 2022 -: 
Added symbols in lex file for variable declaration, created struct data structure for symbol table and link list to store variable info.


