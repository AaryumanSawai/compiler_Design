#include <stdlib.h>
#include<stdio.h>


struct node * create_tree(struct node * right, struct node *left, int op)
{
    struct node* root = (struct node *) malloc(sizeof(struct node));
    root -> left = left;
    root -> right = right;
    root->x = op;
    return root;
    
}
struct node * create_node(int x)
{
    struct node *n1 = (struct node *)malloc(sizeof(struct node));
    n1->x = x;
    n1->right = (struct node *)NULL ;
    n1->left = NULL;
    return n1;
}

void print_tree(struct node *root){
	if(root == NULL)
	{
		return;
	}
	print_tree(root->left);
	printf(" %d " , root->x);
	print_tree( root->right );
}


int eval (struct node *root)
{
	if(root == NULL)
	{
		return 0;
	}
	if(root->right == NULL && root->left == NULL)
	{
		return root->x;
	}
	int lval = eval(root->left);
	int rval = eval(root->right);
	if(root->x == 1)
	{
		return lval+rval;
	}
	
	if(root -> x == 2)
	{
		return lval-rval;
	}
	
	if(root->x == 3)
	{
		return lval*rval;
	}
	
	if(root->x == 4)
	{
		return lval/rval;
	}
}



