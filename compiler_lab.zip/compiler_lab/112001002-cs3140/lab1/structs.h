#include <stdlib.h>
#include<stdio.h>
#ifndef node
struct node
{
    int x;
    struct node *left;
    struct node *right;
};
#endif;
struct node * create_tree(struct node * right, struct node *left, int op);
struct node * create_node(int x);
